# Harmony Studio

A portable music notebook that connects whole-song analysis with hands-on harmony experiments.

**Open `index.html` to start. No installation is required.** Song Atlas and Phrase Lab are two workspaces in one application, with one shared collection and one backup.

## Upload this directly to your GitHub repository

1. Extract the ZIP on your computer.
2. Open your repository on GitHub and choose **Add file → Upload files**.
3. Drag the **contents** of the extracted folder into the upload area, including `index.html`, `src`, `data`, `scripts`, `tests`, `dist`, and `.github`. Commit the upload.

Put `index.html` at the repository's top level. The finished app is already built; you do not need to run commands before uploading. The ZIP contains starter studies and the draft song analysis, without your personal browser collection or recordings.

## Open it as a website with GitHub Pages

The easiest route uses the app already committed at the repository root:

1. In the repository, open **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Select your branch (usually `main`) and **`/ (root)`**, then save.
4. GitHub displays your Pages address when deployment completes.

For a source-build workflow instead, choose **GitHub Actions** as the Pages source, then run **Actions → Publish Harmony Studio to GitHub Pages → Run workflow**. The included workflow is manual; simply uploading the source does not invoke it.

GitHub documents Pages availability and setup in [Configuring a publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) and [Using custom workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages). Availability depends on repository visibility and your GitHub plan. A private repository does not by itself mean that a Pages website is private; check the site's access settings before publishing.

## What it does

- **Song Atlas:** map a full song, its sections, recurring ideas, transitions, chord progression, and melody listening observations.
- **Phrase Lab:** hear individual chords and phrases, alter chords, compare versions, arrange entries, and keep alternatives.
- **In context:** send a bar range from a song to the Lab, then bring an edited phrase back as a separate whole-song variation.
- **One collection:** songs, phrases, alternatives, experiments, notes, favourites, entry order, and music references travel in one JSON backup.
- **Real recordings:** choose local audio to hear the melody alongside a song map. The recording stays on your computer and must be selected again after reopening.
- **Music software:** export MIDI for your DAW or phrase MusicXML for MuseScore/Sibelius.

The included 金莎《着迷》 map has 13 sections and 94 grid bars. It remains an audio-informed **working analysis** with uncertain chord choices visible. Playback uses arranged keyboard and bass voicings. Melody descriptions are listening prompts; loading audio does not automatically transcribe it. No lyrics or complete commercial recording are bundled.

## Keep your collection portable

Use **Back up everything** to download one JSON file. Use **Import backup** to bring it to another browser, computer, or the GitHub Pages version.

Earlier separate Harmony Lab and Song Atlas backups are supported: importing one replaces its corresponding workspace and keeps the other. Import both old backups once, then make a combined backup.

The app saves locally in browser storage. GitHub hosts the program; it does not automatically sync or receive your songs, notes, or recordings. File copies and different website addresses may use different browser storage, so transfer your collection through backups.

## Development

Requires Node.js 20 or later. There are **no third-party runtime or build dependencies**, and no `npm install` step.

```sh
npm test
npm run build
npm start
```

The local preview is at `http://127.0.0.1:4173`. `npm run build` writes identical self-contained apps to `index.html` and `dist/index.html`. The root file supports immediate use and branch-based Pages hosting; `dist` supports the optional Pages workflow.

All assets are embedded in the built HTML. Relative routing works on repository subpaths and from a local file. There are no CDN calls, analytics, accounts, server endpoints, or embedded credentials. External recording links open only when you choose them.

See [Architecture](docs/ARCHITECTURE.md) for the source layout. No open-source licence has been selected for this personal project; add the licence you want before granting redistribution rights.
